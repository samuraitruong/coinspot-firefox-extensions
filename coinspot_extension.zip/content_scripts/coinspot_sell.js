document.querySelector('.sellmax').click();
setInterval(() => document.querySelector('.sellmax').click(), 10000);
