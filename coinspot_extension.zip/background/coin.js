// // chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
// //   console.log('Received %o from %o, frame', msg, sender.tab, sender.frameId);
// //   sendResponse('Gotcha!');
// // });

// var port = chrome.runtime.connect({ name: 'knockknock' });
// port.postMessage({ joke: 'Knock knock' });
// port.onMessage.addListener(function (msg) {
//   console.log(msg);
//   port.postMessage({ answer: 'Madame... Bovary' });
// });
